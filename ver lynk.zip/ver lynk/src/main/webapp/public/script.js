const availableRooms = [
	{ id: 1, name: 'Room A', bookings: [] },
	{ id: 2, name: 'Room B', bookings: [] },
];

const userBookings = [];

// Function to populate available rooms dropdown
function populateRoomOptions() {
	const roomSelect = document.getElementById('room-select');
	roomSelect.innerHTML = '';
	availableRooms.forEach((room) => {
		const option = document.createElement('option');
		option.value = room.id;
		option.text = room.name;
		roomSelect.appendChild(option);
	});
}

// Function to display available rooms
function displayAvailableRooms() {
	const availableRoomsDiv = document.getElementById('available-rooms');
	availableRoomsDiv.innerHTML = '<h2>Available Rooms:</h2>';
	availableRooms.forEach((room) => {
		const roomDiv = document.createElement('div');
		roomDiv.innerHTML = `<p>${room.name}</p><p>Status: ${room.bookings.length > 15 ? 'Booked' : 'Available'
			}</p>`;
		availableRoomsDiv.appendChild(roomDiv);
	});
}

// Function to book a room
function bookRoom() {
	const roomSelect = document.getElementById('room-select');
	const selectedRoomId = parseInt(roomSelect.value);
	const timeSlotInput = document.getElementById('time-slot');
	const selectedTimeSlot = new Date(timeSlotInput.value);

	// Check for conflicts
	const selectedRoom = availableRooms.find((room) => room.id === selectedRoomId);
	const isConflict = selectedRoom.bookings.some(
		(booking) =>
			selectedTimeSlot >= booking.start &&
			selectedTimeSlot < booking.end
	);

	if (!isConflict) {
		// Book the room
		selectedRoom.bookings.push({
			start: selectedTimeSlot,
			end: new Date(selectedTimeSlot.getTime() + 30 * 60000), // 30 minutes
		});

		// Update user bookings
		userBookings.push({
			room: selectedRoom.name,
			timeSlot: selectedTimeSlot.toISOString(),
		});

		// Refresh UI
		displayAvailableRooms();
		displayUserBookings();
	} else {
		alert('This room is already booked for the selected time slot.');
	}
}


// Function to display user's bookings
function displayUserBookings() {
	const bookingsDiv = document.getElementById('bookings');
	bookingsDiv.innerHTML = '<h2>Your Bookings:</h2>';
	userBookings.forEach((booking) => {
		const bookingDiv = document.createElement('div');
		bookingDiv.innerHTML = `<p>Room: ${booking.room}</p><p>Time Slot: ${booking.timeSlot}</p>`;

		// "Cancel" button with data attributes
		const cancelButton = document.createElement('button');
		cancelButton.textContent = 'Cancel';
		cancelButton.classList.add('cancel-button');
		cancelButton.dataset.room = booking.room;
		cancelButton.dataset.timeSlot = booking.timeSlot;

		bookingDiv.appendChild(cancelButton);
		bookingsDiv.appendChild(bookingDiv);
	});
}



// Function to cancel a booking
function cancelBooking(roomName, timeSlot) {
	const selectedRoom = availableRooms.find((room) => room.name === roomName);
	const bookingIndex = selectedRoom.bookings.findIndex(
		(booking) => booking.start.toISOString() === timeSlot
	);

	if (bookingIndex !== -1) {
		// Remove the booking from the room's bookings array
		selectedRoom.bookings.splice(bookingIndex, 1);

		// Remove the booking from the user's bookings
		const userBookingIndex = userBookings.findIndex(
			(booking) => booking.room === roomName && booking.timeSlot === timeSlot
		);
		if (userBookingIndex !== -1) {
			userBookings.splice(userBookingIndex, 1);
		}

		
		displayAvailableRooms();
		displayUserBookings();
	}
}

function populateTimeSlotOptions() {
    const timeSlotSelect = document.getElementById('time-slot');
    timeSlotSelect.innerHTML = '';

    const startTime = new Date();
    startTime.setHours(9, 0, 0); 

    while (startTime.getHours() < 17) {
        const option = document.createElement('option');
        option.value = startTime.toISOString();
        option.text = `${startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${startTime
            .getTime() + 30 * 60 * 1000 >=
            startTime.setMinutes(startTime.getMinutes() + 30)
            ? startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            : (startTime = new Date(startTime.getTime() + 30 * 60 * 1000)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        timeSlotSelect.appendChild(option);
        startTime.setMinutes(startTime.getMinutes());
    }
}

const bookingsDiv = document.getElementById('bookings');
bookingsDiv.addEventListener('click', (event) => {
	if (event.target.classList.contains('cancel-button')) {
		const roomName = event.target.dataset.room;
		const timeSlot = event.target.dataset.timeSlot;
		cancelBooking(roomName, timeSlot);
	}
});


// Initialize the app
populateRoomOptions();
displayAvailableRooms();
displayUserBookings();
populateTimeSlotOptions();

const bookButton = document.getElementById('book-button');
bookButton.addEventListener('click', bookRoom);
